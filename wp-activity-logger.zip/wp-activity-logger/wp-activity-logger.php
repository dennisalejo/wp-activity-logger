<?php
/**
 * Plugin Name: WP Activity Logger
 * Description: This plugin logs user activities such as login, post/page edits, theme updates, and plugin updates including IP address, browser, date and time.
 * Version: 1.1
 * Author: Dennis Alejo
 * Author URI: https://dennis.tips
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class WP_Activity_Logger {
    public function __construct() {
        add_action('wp_login', array($this, 'log_user_login'), 10, 2);
        add_action('save_post', array($this, 'log_post_edit'));
        add_action('activated_plugin', array($this, 'log_plugin_update'));
        add_action('switch_theme', array($this, 'log_theme_update'));
        add_action('admin_menu', array($this, 'register_activity_log_menu'));
        add_action('admin_init', array($this, 'settings_init'));
        add_action('init', array($this, 'create_log_table'));
    }

    public function create_log_table() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'activity_logs';

        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
            $charset_collate = $wpdb->get_charset_collate();
            $sql = "CREATE TABLE $table_name (
                id mediumint(9) NOT NULL AUTO_INCREMENT,
                user_id bigint(20) NOT NULL,
                user_ip varchar(100) NOT NULL,
                user_browser varchar(255) NOT NULL,
                activity_type varchar(100) NOT NULL,
                activity_date datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
                PRIMARY KEY  (id)
            ) $charset_collate;";

            require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
            dbDelta($sql);
        }
    }

    public function log_user_login($user_login, $user) {
        $this->insert_log($user->ID, 'user_login');
        $this->maybe_send_log_email();
    }

    public function log_post_edit($post_id) {
        $post = get_post($post_id);
        $this->insert_log($post->post_author, 'post_edit');
    }

    public function log_plugin_update($plugin) {
        $user_id = get_current_user_id();
        $this->insert_log($user_id, 'plugin_update');
    }

    public function log_theme_update($new_name) {
        $user_id = get_current_user_id();
        $this->insert_log($user_id, 'theme_update');
    }

    private function insert_log($user_id, $activity_type) {
        if(!is_user_logged_in()) return;

        global $wpdb;

        $user_ip = $_SERVER['REMOTE_ADDR'];
        $user_browser = $_SERVER['HTTP_USER_AGENT'];
        $current_time = current_time('mysql');
        
        $wpdb->insert(
            $wpdb->prefix . 'activity_logs',
            array(
                'user_id' => $user_id,
                'user_ip' => $user_ip,
                'user_browser' => $user_browser,
                'activity_type' => $activity_type,
                'activity_date' => $current_time,
            )
        );
    }

    public function register_activity_log_menu() {
        add_menu_page(
            'Activity Logs',
            'Activity Logs',
            'manage_options',
            'wp-activity-logger',
            array($this, 'display_activity_logs'),
            'dashicons-format-aside',
            6
        );
    }

    public function display_activity_logs() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'activity_logs';
        $logs = $wpdb->get_results("SELECT * FROM $table_name ORDER BY activity_date DESC");

        echo '<div class="wrap">';
        echo '<h1>Activity Logs</h1>';
        echo '<table class="widefat fixed" cellspacing="0">';
        echo '<thead><tr><th>User ID</th><th>IP Address</th><th>Browser</th><th>Activity Type</th><th>Date/Time</th></tr></thead>';
        echo '<tbody>';
        foreach($logs as $log) {
            echo '<tr>';
            echo '<td>' . esc_html($log->user_id) . '</td>';
            echo '<td>' . esc_html($log->user_ip) . '</td>';
            echo '<td>' . esc_html($log->user_browser) . '</td>';
            echo '<td>' . esc_html($log->activity_type) . '</td>';
            echo '<td>' . esc_html($log->activity_date) . '</td>';
            echo '</tr>';
        }
        echo '</tbody>';
        echo '</table>';
        echo '</div>';
    }

    public function settings_init() {
        add_settings_section(
            'wp_activity_logger_section',
            'WP Activity Logger Settings',
            null,
            'general'
        );
        
        add_settings_field(
            'wp_activity_logger_email',
            'Log Email Address',
            array($this, 'log_email_field_callback'),
            'general',
            'wp_activity_logger_section'
        );

        register_setting('general', 'wp_activity_logger_email', 'sanitize_email');
    }

    public function log_email_field_callback() {
        printf(
            '<input type="email" id="wp_activity_logger_email" name="wp_activity_logger_email" value="%s" class="regular-text ltr" />',
            esc_attr(get_option('wp_activity_logger_email', ''))
        );
    }

    private function maybe_send_log_email() {
        $email = get_option('wp_activity_logger_email');

        if (!$email) {
            return;
        }

        global $wpdb;
        $logs = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}activity_logs WHERE activity_date >= (NOW() - INTERVAL 1 DAY) ORDER BY activity_date DESC");
        
        if (empty($logs)) {
            return;
        }

        $subject = 'Daily Activity Logs';
        $message = '<h1>Daily Activity Logs</h1><table><thead><tr><th>User ID</th><th>IP Address</th><th>Browser</th><th>Activity Type</th><th>Date/Time</th></tr></thead><tbody>';
        foreach ($logs as $log) {
            $message .= sprintf('<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>', esc_html($log->user_id), esc_html($log->user_ip), esc_html($log->user_browser), esc_html($log->activity_type), esc_html($log->activity_date));
        }
        $message .= '</tbody></table>';

        $headers = array('Content-Type: text/html; charset=UTF-8');
        wp_mail($email, $subject, $message, $headers);
    }
}

new WP_Activity_Logger();

function wp_activity_logger_footer() {
    echo '<p style="text-align: center;">Powered by: <a href="https://instantwebtools.co" target="_blank">Instant Web Tools, LLC</a></p>';
}

add_action('wp_footer', 'wp_activity_logger_footer');
?>