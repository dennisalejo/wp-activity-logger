=== WP Activity Logger ===
Contributors: Dennis Alejo
Donate link: https://dennis.tips
Tags: logs, activity, security, monitoring, logger
Requires at least: 5.0
Tested up to: 6.0
Stable tag: 1.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==

This plugin logs user activities such as login, post/page edits, theme updates, and plugin updates including IP address, browser, date and time. Now you can also view the logs directly from your WordPress admin, and set up email notifications for the logs.

== Installation ==

1. Upload `wp-activity-logger` to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Configure the email settings in the 'Settings' > 'General' menu.

== Changelog ==

= 1.1 =
* Added feature to view logs in WordPress admin.
* Added email notification feature for logs.

= 1.0 =
* First release.

== Upgrade Notice ==

= 1.1 =
* Added viewing logs in admin and email notifications.

= 1.0 =
* Initial release of WP Activity Logger.

== Frequently Asked Questions ==

= How can I view the logs? =

You can view logs directly from the WordPress admin sidebar under the "Activity Logs" menu.

= How can I enable email notifications of logs? =

You can configure the email notification for logs in 'Settings' > 'General' of your WordPress dashboard by entering an email address.